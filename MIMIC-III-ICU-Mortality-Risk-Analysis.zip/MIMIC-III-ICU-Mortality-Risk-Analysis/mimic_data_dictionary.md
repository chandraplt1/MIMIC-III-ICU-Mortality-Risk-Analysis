
# MIMIC-III Data Dictionary (Subset)

## Key Columns

### admissions.csv
- subject_id: Unique patient identifier
- hadm_id: Unique hospital admission ID
- admittime: Timestamp of hospital admission
- dischtime: Timestamp of discharge
- admission_type: Type of admission (EMERGENCY, ELECTIVE, etc.)

### patients.csv
- subject_id: Patient identifier (joins with other tables)
- gender: Patient gender
- dob: Date of birth
- dod: Date of death (if applicable)

### icustays.csv
- icustay_id: ICU stay identifier
- intime: ICU admission time
- outtime: ICU discharge time
- los: Length of stay (days)

### dashboard_summary.csv (Engineered)
- age_group: Patient age category
- mortality_rate: Percentage of patients in group who died
- gender: Male/Female categories
- icu_type: ICU type (MICU, SICU, etc.)
